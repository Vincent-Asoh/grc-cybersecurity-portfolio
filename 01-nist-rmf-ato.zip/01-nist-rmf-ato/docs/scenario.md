> **SIMULATION — fictional organization, assets, personnel roles, evidence, and outcomes. No live systems were scanned or audited.**

# Scenario and evidence conventions

**Organization:** Alder Bridge Services (ABS), a fictional 250-person business document-processing provider. **System:** Client Document Exchange (CDX), used to receive customer files and publish processing status. No real customer, employer, credentials, or production records are included.

**Scope:** Eight illustrative assets, one application boundary, identity and logging dependencies, backup recovery, and a simulated customer security contract. Dates are a fixed September 2026 exercise, not a claim about current exposure. Historical CVEs are deliberately used for repeatable analysis of legacy components.

**Roles:** System Owner (Operations Director), ISSO/GRC Analyst, Security Assessor, Authorizing Official (executive role for simulation), VM Analyst, Platform Lead, IAM Lead, SOC Lead, Risk Committee, Internal Audit Lead. Roles are fictional and do not represent signatures or actual approvals.

**Data:** Business documents with limited customer contact information. No payment-card data, patient health records, government classified data, or assumed CUI. Addresses use private space and domains use `.example`.

**Evidence:** All evidence is authored sample material. An evidence ID identifies a reproducible fixture or narrative, not a collected production record. CSVs have a `simulation=TRUE` column. Blank closure dates mean unresolved, never zero. `n.a.` means not applicable; `unknown` means not established. All deadlines use calendar days and reporting closes at 2026-09-30 end of day.

**Integrity:** Findings are retained when mitigated or accepted; closure requires a successful retest. Planned target risk is kept separate from current residual risk. Simulated approvals establish only the scenario decision. Real implementation would require verified scope, authorized collection, business review, and accountable sign-off.
