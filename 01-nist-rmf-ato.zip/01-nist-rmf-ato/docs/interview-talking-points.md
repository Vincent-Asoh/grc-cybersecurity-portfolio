> **SIMULATION — fictional organization, assets, personnel roles, evidence, and outcomes. No live systems were scanned or audited.**

# Interview walkthrough

## Explain the authorization decision

Suggested explanation after reviewing the artifacts: “I translated the system boundary and impact into selected control statements, then followed evidence through findings and POA&M. I withheld the simulated authorization because a privileged MFA bypass remained, even though another risk had been accepted.”

## Show the work

Walk through F-01 → P-01 → decision memo. Explain why eight controls do not equal the Moderate baseline.

## Follow-up: How do inherited controls affect accountability?

I identify the provider and customer responsibilities, review applicable assurance evidence, and assess customer configuration. A provider assertion alone does not prove effectiveness.

## Honest positioning

Describe this as a self-directed portfolio simulation. Say “I modeled” or “I analyzed the supplied synthetic cases,” not “I secured a real enterprise” or “I operated Nessus/Qualys in production.” Read and personalize the explanation before using it. Discuss a limitation and what evidence you would collect next in an authorized environment.
