> **SIMULATION — fictional organization, assets, personnel roles, evidence, and outcomes. No live systems were scanned or audited.**

# Sources and version decisions

Reference review: 2026-10-01. Scenario reporting date: 2026-09-30. Narrative summaries and control mappings are original analyst interpretations; copyrighted standard text is not reproduced.

| Reference | Use and limitation |
|---|---|
| [NIST SP 800-37 Rev. 2](https://csrc.nist.gov/pubs/sp/800/37/r2/final) | RMF structure: Prepare, Categorize, Select, Implement, Assess, Authorize, Monitor. |
| [FIPS 199](https://csrc.nist.gov/pubs/fips/199/final) | Illustrative confidentiality, integrity, availability categorization. |
| [NIST SP 800-53 Rev. 5](https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final) | Selected control references; NIST notes Release 5.2.0 in August 2025. This sample is not a complete baseline or implementation of every update. |
| [NIST SP 800-53B](https://csrc.nist.gov/pubs/sp/800/53/b/upd1/final) | Baseline selection and tailoring reference; selected examples do not constitute the Moderate baseline. |
| [NIST SP 800-53A Rev. 5](https://csrc.nist.gov/pubs/sp/800/53/a/r5/final) | Examine, interview, test approach; procedures here are abbreviated custom tests. |
| [NIST SP 800-30 Rev. 1](https://csrc.nist.gov/pubs/sp/800/30/r1/final) | Scenario-based risk assessment; the 5x5 matrix is a local fictional policy. |
| [NIST CSF 2.0](https://nvlpubs.nist.gov/nistpubs/CSWP/NIST.CSWP.29.pdf) | Six functions; crosswalk uses category-level mappings, not full subcategory coverage. |
| [ISO/IEC 27001:2022](https://www.iso.org/standard/27001) | ISMS and Annex A references; no certification claim. Use the licensed standard for formal conformity work. |
| [NIST crosswalk caution](https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final) | Mappings indicate relationships, not equivalence or proof of compliance. |
| [FIRST CVSS 3.1 specification](https://www.first.org/cvss/v3-1/specification-document) | Frozen base-score examples; CVSS severity is not business risk. No score conversion to CVSS 4.0. |
| [Oracle Log4j advisory](https://www.oracle.com/security-alerts/alert-cve-2021-44228.html) | CVE-2021-44228 base 10.0 and vector characteristics; actual deployment applicability remains scenario data. |
| [Apache security advisories](https://logging.apache.org/security.html) | Product-specific patch review; choose a supported release addressing all applicable advisories, not merely the earliest Log4Shell fix. |
| [Tenable CVE-2023-34362](https://www.tenable.com/cve/CVE-2023-34362) | MOVEit vulnerability reference; portfolio uses a frozen illustrative base vector and explicitly fictional installation. |
| [NVD CVE-2023-34362](https://nvd.nist.gov/vuln/detail/CVE-2023-34362) | Further reference; automated retrieval returned no readable detail during preparation. |
| [Tenable credentialed checks](https://docs.tenable.com/nessus/10_10/Content/NessusCredentialedChecks.htm) | Successful login alone is insufficient; validate local checks/package inventory. |
| [Qualys VMDR host authentication](https://docs.qualys.com/en/vmdr/latest/authentication/authentication_lp.htm) | Configure and verify host authentication and scan options. |

Compliance requirements in this portfolio are fictional customer contract clauses and internal policy obligations. Federal authorization terminology is used only as a training analogue. HIPAA, PCI DSS, SOX, and CUI requirements are not assumed applicable. ISO mappings are topic-level analyst suggestions, not an authoritative crosswalk.
