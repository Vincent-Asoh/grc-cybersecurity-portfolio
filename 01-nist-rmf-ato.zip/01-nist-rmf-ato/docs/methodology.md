> **SIMULATION — fictional organization, assets, personnel roles, evidence, and outcomes. No live systems were scanned or audited.**

# RMF methodology

| Step | Work performed | Decision or artifact |
|---|---|---|
| Prepare | Define service, roles, stakeholders, information flows and risk tolerance | Scenario; owner accountable for CDX |
| Categorize | Rate information types and apply objective-wise high-water marks | C=Moderate, I=Moderate, A=Moderate |
| Select | Use Moderate baseline as a starting point; document sample controls and inherited responsibilities | Eight illustrative control statements; full baseline work remains outside exercise |
| Implement | Describe who does what, with what mechanism, cadence and evidence | SSP and control register |
| Assess | Examine fixtures, interview simulated owners, test six objectives | SAR with three initial deficiencies |
| Authorize | Compare unresolved weaknesses with fictional risk tolerance | Withhold approval; accept only a bounded retention gap |
| Monitor | Track expiring exceptions, configuration changes and control performance | Monthly review plus event-driven reassessment |

Tailoring does not mean arbitrarily dropping difficult controls. In a real package, document every baseline control/enhancement, applicability, organization-defined parameter, common-control provider, assessment objective and approving authority. No overlay or full privacy-control selection is claimed here. The hypothetical impact level is a training judgment, not an official information-type determination.

Assessment window: September 14–18; closure cutoff: September 30. The assessor role is separate from implementation owners. Satisfied sample tests support only the tested objective and time period, not the effectiveness of an entire control family.
