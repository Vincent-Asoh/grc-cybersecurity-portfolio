> **SIMULATION — fictional organization, assets, personnel roles, evidence, and outcomes. No live systems were scanned or audited.**

# Security Assessment Report

**Assessor:** Security Assessor role, independent of owners. **Scope:** six selected objectives; September 14–18. Fixtures are in [evidence](evidence-fixtures.md); procedures and populations are in [test results](test-results.csv).

| Finding | Condition and risk | Root cause | Rating | Recommendation / disposition |
|---|---|---|---|---|
| F-01 | One of six privileged paths lacks MFA, permitting password-only privileged access | Legacy integration excluded from IAM rollout | High | P-01: block legacy path or enforce MFA by Oct 7; open at cutoff |
| F-02 | Only 30 of required 90 online log days configured; historical investigation is impaired | Storage budget did not account for policy retention | Moderate | P-02: expand retention by Oct 30; accepted temporarily under RA-01 |
| F-03 | A03 local scan checks unavailable; missing patches could remain undetected | Scan credential expired | Moderate | P-03: rotate vaulted credential and retest; closed Sep 28 |

Initial result: 3 satisfied and 3 other-than-satisfied objectives. Sep 28 evidence closes F-03 only. A08 enterprise scan coverage remains unresolved in the VM project and is not concealed by the scoped A03 closure. No reclassification of F-01 as accepted is permitted by RA-01.

Recommendation: withhold authorization until F-01 is retested successfully; maintain the time-bound log retention exception. Assessment limitations include small populations, fixture evidence and incomplete baseline coverage. Results do not support a conclusion that CDX complies with all NIST requirements.
