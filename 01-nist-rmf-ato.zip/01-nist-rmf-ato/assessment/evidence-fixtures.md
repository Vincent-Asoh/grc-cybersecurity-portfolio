> **SIMULATION — fictional organization, assets, personnel roles, evidence, and outcomes. No live systems were scanned or audited.**

# Evidence fixtures

These excerpts are deliberately authored sample records. They are the complete available evidence for this exercise.

| ID | Date / population | Sample record and interpretation |
|---|---|---|
| EV-01 | Sep 14; 6 active privileged accounts | Six approvals have owner and expiry fields. Two September leavers were disabled in 6 and 11 hours. No late removal in this small sample. |
| EV-02 | Sep 14; 6 privileged access paths | Five paths challenge for MFA. Legacy A04 console path permits a password-only privileged session in the fixture. Policy export requires six of six. |
| EV-03 | Sep 15; collector configuration and 5 daily reviews | Retention configuration `online_days: 30`; policy `minimum_online_days: 90`. Five sampled daily alert reviews have disposition. This supports AU-6, but fails AU-11. |
| EV-04 | Sep 14 initial; Sep 28 retest | Initial local-check success on 6 of 8 assets. A03 and A08 fail authentication. Sep 28 retest shows A03 local inventory collected; A08 remains unsuccessful. The scoped RMF deficiency was A03; enterprise VM coverage still has A08 outstanding. |
| EV-05 | Sep 1–4; emergency change CHG-001 | A01 critical exposure detected Sep 1, isolated same day, repaired Sep 3, authenticated retest Sep 4. Owner release and rollback records supplied in VM example. |
| EV-06 | Sep 16; one restore | Backup age 12 hours; restore elapsed 6 hours; 200 of 200 fixture record hashes match. Meets sample RPO 24h and RTO 8h. One test does not demonstrate full disaster recovery readiness. |

Evidence owners: IAM Lead EV-01/02; SOC Lead EV-03; VM Analyst EV-04; Platform Lead EV-05/06. Assessor records independent conclusions from these supplied fixtures; authenticity is not asserted outside the simulation.
