> **SIMULATION — fictional organization, assets, personnel roles, evidence, and outcomes. No live systems were scanned or audited.**

# RA-01 — temporary log-retention risk acceptance

**Related records:** F-02 / P-02 / AU-11. **Requested:** Sep 18. **Simulated approval:** Sep 20 by the Authorizing Official role; system owner concurs. **Expires:** Oct 30 at end of day. **Residual rating:** Moderate (likelihood 3 × impact 3 = 9 under local risk policy).

Thirty online log days leave a 60-day shortfall against policy. Additional capacity requires procurement and ingestion testing. Cost and delivery timing justify a short, bounded delay, not permanent noncompliance.

Compensating measures: daily SOC review, restricted deletion permissions, and weekly export of high-value incident records. These measures improve detection and preservation for selected events; they do not supply complete 90-day searchability. EV-03 supports daily review; export effectiveness remains an assumption to verify weekly.

SOC Lead owns expansion and checks the oldest searchable record every week. Revoke early if deletion protection fails, a relevant incident occurs, or the procurement milestone slips past Oct 10. At expiry, escalate to the executive role and restrict affected service operations if risk remains outside tolerance; no automatic renewal. A new decision requires new evidence and explicit approval.

This decision covers only retention. It does not accept the MFA gap, waive customer obligations, authorize the system, or close the POA&M item.
