> **SIMULATION — fictional organization, assets, personnel roles, evidence, and outcomes. No live systems were scanned or audited.**

# CDX boundary

```mermaid
flowchart LR
  C[Customer browser] --> G
  subgraph CDX[Application boundary]
    G[A01 Exchange gateway] --> A[A02 Application]
    A --> D[A03 Database]
    S[A08 Staging - isolated]
  end
  W[A07 Admin workstation] --> I[A04 Shared identity]
  I --> A
  G --> L[A05 Shared logging]
  A --> L
  D --> B[A06 Shared backup]
```

Conceptual only; arrows show selected business and security flows, not a complete firewall rule set. Shared services require customer/provider responsibility review.
