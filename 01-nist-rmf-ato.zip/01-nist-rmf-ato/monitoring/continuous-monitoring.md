> **SIMULATION — fictional organization, assets, personnel roles, evidence, and outcomes. No live systems were scanned or audited.**

# Continuous monitoring

| Measure | Owner / cadence | Threshold and response |
|---|---|---|
| Privileged paths with MFA | IAM Lead / weekly and every identity change | Must be 6/6; any failure blocks release |
| Local scan check success | VM Analyst / weekly | >=95% enterprise target; failed hosts receive coverage ticket within 1 day |
| Oldest searchable log | SOC Lead / weekly | 90 days after remediation; until then review RA-01 conditions |
| Restore result | Platform Lead / monthly | RTO <=8h and RPO <=24h; failure escalated same day |
| Open and overdue POA&M | ISSO / weekly | Escalate overdue items to owner and risk committee |
| Exception expiry | ISSO / weekly | Notify owner 14 and 7 days before expiry; no automatic extension |

A major change, incident, failed inherited control or changed data classification triggers out-of-cycle review. Preserve evidence before replacing a configuration; link the change ticket, retest, updated risk and decision memo.
