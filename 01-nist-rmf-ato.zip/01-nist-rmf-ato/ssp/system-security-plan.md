> **SIMULATION — fictional organization, assets, personnel roles, evidence, and outcomes. No live systems were scanned or audited.**

# System Security Plan — CDX, version 1.0

**Owner:** Operations Director. **Security lead:** ISSO. **Status:** assessment complete; authorization withheld. **Review date:** September 30, 2026.

## Mission, boundary and data

CDX receives business documents over HTTPS, stores them in a private data tier, and exposes processing status to staff. The application boundary includes A01 exchange gateway, A02 application host, A03 database and A08 staging host. A04 identity, A05 central logging and A06 backup are supporting services with shared responsibilities. A07 is an administrator workstation outside the application boundary but in the enterprise assessment scope. VM and audit projects cover all eight assets.

Traffic flows: customer browser → exchange gateway → private application → database. Administrative access enters through a restricted management path with identity checks. Application and identity events feed the central collector; database backups move to a separately administered backup service. No direct public database access is permitted. See [boundary diagram](../assets/boundary.md).

## Security categorization

The [information-type analysis](categorization.csv) yields SC(CDX)={(confidentiality, Moderate),(integrity, Moderate),(availability, Moderate)}. Serious customer disclosure, material workflow corruption, and a multi-day processing interruption justify Moderate; the scenario does not posit severe/catastrophic mission impacts. The owner should revisit the rating if regulated data, critical services, or contractual availability commitments change.

## Selected controls and parameters

[Control implementations](control-implementations.csv) distinguish system, inherited, and hybrid responsibilities. Policy choices include daily log review, 90-day online log retention, quarterly privileged access review, weekly authenticated scanning and monthly restore testing. These are fictional organization-defined parameters, not universal NIST requirements.

## Dependencies and limitations

The assumed cloud provider manages physical facilities; ABS remains responsible for identity configuration, virtual machines, application permissions, encryption configuration and evidence review. A supplier assurance summary is an assumption, not proof of inherited control effectiveness. No physical-security control is scored as satisfied based on that assumption. Eight implementation examples and six tests cannot establish full baseline conformity.

## Change control

The owner maintains version history; architecture changes, new information types, major incidents, supplier changes or repeated KRI breaches trigger reassessment. ISSO links every weakness to a POA&M item and preserves evidence of closure. The executive decision is in [the decision memo](../authorization/decision-memo.md).
