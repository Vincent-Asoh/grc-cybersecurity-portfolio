> **SIMULATION — fictional organization, assets, personnel roles, evidence, and outcomes. No live systems were scanned or audited.**

# NIST RMF / SSP and ATO Decision Simulation

An authorization package for a fictional document-processing system: from impact categorization to an evidence-based decision to withhold authorization pending remediation.

## Review in five minutes

1. Read the [system security plan](ssp/system-security-plan.md) and [categorization](ssp/categorization.csv).
2. Trace [control implementations](ssp/control-implementations.csv) into the [assessment report](assessment/security-assessment-report.md).
3. Review the [POA&M](remediation/poam.csv), [risk acceptance](authorization/risk-acceptance.md), and [authorization decision](authorization/decision-memo.md).
4. Follow the [RMF methodology](docs/methodology.md) and [monitoring plan](monitoring/continuous-monitoring.md).

## Key findings

Three of six tested objectives were not satisfied: credential coverage, privileged MFA coverage, and log retention. One of these was retested and closed by September 30. Two POA&M items remain open; log retention has time-limited acceptance. A critical scanner finding is closed in the VM case, but the MFA gap still prevents the simulated authorization.

## Skills demonstrated

NIST RMF, FIPS 199 categorization, NIST SP 800-53 implementation statements, control inheritance, assessment evidence, POA&M management, authorization recommendations, risk acceptance, and continuous monitoring.

## Repository guide

`ssp/` defines the boundary and controls; `assessment/` contains tests and evidence; `remediation/` tracks actions; `authorization/` records decisions; `monitoring/` defines follow-up. [Scenario](docs/scenario.md), [sources](docs/sources.md), [diagram](assets/boundary.md), and [interview notes](docs/interview-talking-points.md) explain assumptions and use.

This is an abbreviated training package, not a complete Moderate baseline, actual ATO, FedRAMP package, or claim of federal authorization experience.
