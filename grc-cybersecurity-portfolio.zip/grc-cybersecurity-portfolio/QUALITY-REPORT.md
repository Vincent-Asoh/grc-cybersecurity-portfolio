> **SIMULATION — fictional organization, assets, personnel roles, evidence, and outcomes. No live systems were scanned or audited.**

# Artifact validation report

Package prepared 2026-10-01; fixed scenario cutoff 2026-09-30.

- Parsed 15 CSV files containing 117 populated data records; checked consistent column counts and simulation flags.
- Checked local Markdown file links across the portfolio and standalone project structure.
- Recomputed VM dates and SLA intervals; checked valid asset references and finding-ID uniqueness.
- Reproduced metrics from delivered input CSVs: 12 cases, 11 valid, 6 closed, 5 unresolved, 3 overdue; 4/7 due cases closed on time (57.1%); MTTR 64/6 = 10.67 days. Two other closed cases were not yet due at cutoff and are excluded from the due-cohort denominator.
- Reconciled risk scores and bands: 1 current Critical, 4 High, 5 Moderate.
- Reconciled audit outcomes: 4 Effective, 3 Ineffective, 1 Not demonstrated; 5/8 evidence requests complete on time.
- Reviewed shared MFA, retention, credential and patch issues for consistent scope, decisions and dates.

Verification is artifact validation only. No real scanner, live GitHub upload, control operation, vendor dashboard or certified audit was executed. Mermaid diagrams are supplied as GitHub-compatible text; optional screenshot slots are explicitly labeled. CSV values are static and metric regeneration is documented.
