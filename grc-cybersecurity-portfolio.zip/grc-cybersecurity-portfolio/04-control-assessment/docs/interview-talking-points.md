> **SIMULATION — fictional organization, assets, personnel roles, evidence, and outcomes. No live systems were scanned or audited.**

# Interview walkthrough

## Explain a defensible audit finding

Suggested explanation after reviewing the artifacts: “I started with applicable fictional requirements, requested dated evidence, tested specific samples and wrote condition-cause-effect findings. I distinguished a failed control from missing evidence and mapped topics without claiming equivalence.”

## Show the work

Trace CTR-02 → C-03 → E-03 → W-03 → AF-02 → CA-02.

## Follow-up: Can an accepted risk be an audit finding?

Yes. Internal acceptance does not prove the control works or waive a customer requirement. I retain the failed criterion, document the decision and monitor corrective action.

## Honest positioning

Describe this as a self-directed portfolio simulation. Say “I modeled” or “I analyzed the supplied synthetic cases,” not “I secured a real enterprise” or “I operated Nessus/Qualys in production.” Read and personalize the explanation before using it. Discuss a limitation and what evidence you would collect next in an authorized environment.
