> **SIMULATION — fictional organization, assets, personnel roles, evidence, and outcomes. No live systems were scanned or audited.**

# Audit plan and testing method

**Period:** Sep 1–30, 2026. **Fieldwork:** Sep 14–30. **Assessor:** Internal Audit Lead, independent of control owners. **Scope:** eight selected objectives supporting CDX, including shared-service dependencies. No full standard certification or statistical population assurance is intended.

Define criterion → request evidence → verify period/scope/completeness → evaluate design → sample operation → compare expected and observed → discuss factual accuracy with owner → issue finding → track action → independently retest closure.

Sampling is purposeful: all six privileged paths, two leavers, five due vulnerability cases, one collector, all eight assets, one restore, one emergency change and one supplier. The five VM cases are V-001, V-002, V-005, V-008 and V-012; they test both critical response and routine patch timeliness. These small nonrandom samples do not estimate organization-wide failure rates.

**Design:** would the specified process meet its objective if implemented? **Operating effectiveness:** does the sample show it actually worked in the period? Effective means the sampled criteria are met; Ineffective means a criterion fails; Not demonstrated means evidence cannot support a conclusion. Adequate policy design does not imply effective operation.

Evidence acceptance requires scope, date, owner and sufficient detail to reproduce the decision. Interviews alone cannot establish configuration effectiveness. In a real engagement, preserve originals, hashes, collection dates, provenance and access restrictions. Here, fixtures are transparently authored substitutes.

High finding: enables material unauthorized access or leaves a significant remediation breach. Moderate: reduces detection or assurance without evidence of immediate severe exposure. These audit ratings are qualitative and separate from the risk-register 5x5 scores. Owners propose actions; audit validates closure evidence and records residual limitations.
