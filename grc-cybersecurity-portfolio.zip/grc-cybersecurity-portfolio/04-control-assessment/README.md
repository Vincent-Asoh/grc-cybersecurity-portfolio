> **SIMULATION — fictional organization, assets, personnel roles, evidence, and outcomes. No live systems were scanned or audited.**

# Compliance and Security Control Assessment

An evidence-led internal audit simulation mapping eight control objectives across NIST CSF 2.0, NIST SP 800-53 Rev. 5, ISO/IEC 27001:2022 and fictional customer/internal requirements.

## Review in five minutes

1. Read [scope and methodology](docs/methodology.md) and [applicable requirements](mapping/applicability.md).
2. Compare the [control crosswalk](mapping/control-crosswalk.csv) and [evidence requests](evidence/evidence-requests.csv).
3. Trace [testing workpapers](testing/workpapers.csv) to [evidence fixtures](evidence/fixtures.md), [findings](findings/findings.csv), and [corrective actions](remediation/corrective-actions.csv).
4. Read the [executive report](reports/executive-summary.md).

## Key findings

Eight objectives tested: four Effective, three Ineffective and one Not demonstrated. MFA, patch timeliness and log retention fail their criteria; supplier assurance lacks sufficient evidence. Five of eight requests arrive complete and on time; two are late and one is incomplete. A missing document is an assurance limitation, not proof of a technical exploit.

## Skills demonstrated

Audit scoping, compliance applicability, evidence requests, sampling, design and operating-effectiveness testing, NIST/ISO crosswalks, defensible findings, corrective actions, management responses and executive reporting.

The assessment is not an ISO certification audit, complete statement of applicability, or legal compliance opinion. Mappings are analyst interpretations at CSF category level, not equivalent requirements.

[Scenario](docs/scenario.md) · [Sources](docs/sources.md) · [Interview notes](docs/interview-talking-points.md) · [Audit flow](assets/audit-flow.md)
