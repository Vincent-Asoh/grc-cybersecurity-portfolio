> **SIMULATION — fictional organization, assets, personnel roles, evidence, and outcomes. No live systems were scanned or audited.**

# Audit evidence fixtures

| ID | Supplied sample evidence |
|---|---|
| E-01 | Six privileged paths; five enforce MFA, one A04 legacy path accepts password only. Same condition as RMF EV-02 and VM V-004. |
| E-02 | Six approved privileged accounts; two leavers disabled in 6h and 11h; policy maximum 24h. |
| E-03 | V-001 due Sep 4/closed Sep 4; V-002 due Sep 5/closed Sep 5; V-005 due Sep 19/open; V-008 due Sep 22/closed Sep 18; V-012 due Sep 28/closed Sep 28. Four of five selected cases meet the deadline; one fails. |
| E-04 | Collector online retention=30 days versus contract=90; five daily review entries complete. |
| E-05 | Sep 14 reconciliation lists all eight observed assets with owner. A08 was missing from prior CMDB and was assigned to App Lead the same day. Inventory criterion passes; unsuccessful vulnerability local checks remain a separate gap. |
| E-06 | Sep 16 restore: backup age 12h, recovery 6h, 200/200 hashes match. |
| E-07 | CHG-001 approval Sep 1; staged checks 20/20 Sep 2; isolated rollback plan; deployment Sep 3; independent closure Sep 4. |
| E-08 | Supplier contact and contract available; current assurance report and documented review absent. No evidence supports completion of annual assurance review. |

These fixtures constitute the whole available sample. They are not screenshots, vendor reports, digitally signed records or evidence collected from a real environment.
