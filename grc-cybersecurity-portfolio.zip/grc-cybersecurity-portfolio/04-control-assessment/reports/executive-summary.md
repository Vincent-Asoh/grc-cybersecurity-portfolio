> **SIMULATION — fictional organization, assets, personnel roles, evidence, and outcomes. No live systems were scanned or audited.**

# Internal control assessment — executive report

**Conclusion:** The eight-objective sample does not support overall control effectiveness. Four objectives are Effective, three Ineffective and one Not demonstrated. Two High findings require prompt treatment; two Moderate findings require corrective action and assurance follow-up.

Privileged MFA coverage and database patch timeliness are the leading concerns. The retention exception documents internal risk acceptance but does not make the 90-day customer requirement satisfied. Management must resolve the contractual gap with the appropriate business owner; an internal approver cannot unilaterally waive a customer obligation.

Evidence delivery also needs improvement: five of eight requests were complete and on time (62.5%); two complete requests arrived late and one was incomplete. This is an evidence-service KPI, not a compliance percentage. Four of five selected vulnerability cases met their original deadline; this small purposeful sample is not the entire VM population.

**Actions:** prioritize CA-01 MFA by Oct 7 and CA-02 database patch by Oct 3; approve retention capacity and require vendor assurance review. Audit will retest before closure and report unresolved actions at the next risk committee review. As of Sep 30 all four corrective actions remain open.

**Limits:** authored fixture evidence; eight selected objectives; small nonrandom samples; no independent collection; no full ISO clauses, baseline, legal obligations or certification coverage. Effective sample results do not imply complete compliance with any mapped framework.
