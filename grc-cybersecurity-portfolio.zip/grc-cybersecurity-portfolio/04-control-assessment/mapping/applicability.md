> **SIMULATION — fictional organization, assets, personnel roles, evidence, and outcomes. No live systems were scanned or audited.**

# Requirement applicability and scope

ABS is a fictional commercial service provider. For this assessment, its fictional customer contract and internal policies are mandatory criteria. NIST and ISO references provide comparison and structure; they are not independently assumed legally mandatory. Government ATO terminology belongs to the separate training simulation.

| ID | Fictional requirement | Applicability rationale |
|---|---|---|
| CTR-01 | All privileged paths require MFA | Applies to the six CDX/shared-service privileged paths |
| CTR-02 | Resolve P1 within 3, P2 within 14, P3 within 30 and P4 within 90 calendar days | Applies to valid enterprise VM cases; accepted cases retain original due date |
| CTR-03 | Keep security logs searchable online for 90 days | Applies to central collector supporting CDX |
| CTR-04 | Demonstrate RTO <=8h and RPO <=24h in monthly restore tests | Applies to CDX recovery fixture |
| CTR-05 | Annual assurance review of critical suppliers must be documented | Applies to one fictional hosting supplier |
| POL-02 | Approved privileged accounts; leavers disabled within 24h | Applies to IAM sample |
| POL-03 | Weekly asset reconciliation and assignment of an owner | Applies to eight-asset inventory |
| POL-04 | Production changes require approval, testing and rollback records | Applies to sampled emergency change |

Payment processing, healthcare delivery, public-company financial reporting and CUI processing are not established in the scenario; therefore PCI DSS, HIPAA, SOX and NIST SP 800-171 are not added as assumed obligations. A real applicability review would verify contracts, jurisdictions, data types, entities and business processes with the appropriate owners.

ISO Annex A references indicate related topics only. Formal ISO/IEC 27001 conformity also requires ISMS clauses, scope, risk treatment and a statement of applicability; those are not assessed in full here.
