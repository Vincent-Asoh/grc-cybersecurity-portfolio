> **SIMULATION — fictional organization, assets, personnel roles, evidence, and outcomes. No live systems were scanned or audited.**

# Worked assessment — R-02 privileged access

**Business objective:** prevent unauthorized changes and customer-file access. **Threat event:** an attacker obtains a password and signs in through a legacy privileged path. **Weakness:** one of six paths bypasses MFA. **Consequence:** broad access to confidential documents and service configuration.

Inherent likelihood 4, impact 5 → 20 Critical. EV-02 demonstrates the bypass. Five protected paths and account reviews do not remove the bypass, so current likelihood stays 4 and impact 5 → 20 Critical. Do not average five good paths with one bad path into a reassuring score.

Treatment: disable the legacy path or integrate it with MFA; IAM Lead owns the Oct 7 deadline. Assessor tests all six paths, recovery and break-glass handling, records expected/observed results and verifies alerting. The planned target is likelihood 2 × impact 5 = 10 Moderate. Impact remains severe because privileged compromise is still consequential even when less likely.

Target is not current residual risk. Only verified enforcement and owner review can support a score change. The risk committee rejects release acceptance at Sep 30. RMF authorization is withheld; VM V-004 and audit AF-01 carry the implementation and assurance work.

## Comparison — R-04 recovery

Separate backup administration and one successful restore support a reduction from 20 to current 10, but confidence is Medium because this does not prove full-service recovery under attack. Target impact 4 assumes the planned complete exercise proves a shorter maximum disruption. If testing fails, the forecast reduction must be removed.
