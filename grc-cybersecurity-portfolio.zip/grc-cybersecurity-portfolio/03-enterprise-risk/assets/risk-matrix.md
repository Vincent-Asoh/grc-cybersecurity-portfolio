> **SIMULATION — fictional organization, assets, personnel roles, evidence, and outcomes. No live systems were scanned or audited.**

# Local 5 × 5 matrix

Cells show likelihood × impact; use the methodology's descriptive anchors.

| Likelihood ↓ / Impact → | 1 | 2 | 3 | 4 | 5 |
|---|---|---|---|---|---|
| 5 | 5 Low | 10 Moderate | 15 High | 20 Critical | 25 Critical |
| 4 | 4 Low | 8 Moderate | 12 High | 16 High | 20 Critical |
| 3 | 3 Low | 6 Moderate | 9 Moderate | 12 High | 15 High |
| 2 | 2 Low | 4 Low | 6 Moderate | 8 Moderate | 10 Moderate |
| 1 | 1 Low | 2 Low | 3 Low | 4 Low | 5 Low |

At cutoff: R-02=(4,5); R-05/06/08/10=(3,4); R-01/04=(2,5); R-03=(3,3); R-07/09=(2,4). Planned targets must not replace these coordinates until verified.
