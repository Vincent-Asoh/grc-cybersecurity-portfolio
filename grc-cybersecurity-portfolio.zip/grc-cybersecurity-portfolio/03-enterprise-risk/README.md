> **SIMULATION — fictional organization, assets, personnel roles, evidence, and outcomes. No live systems were scanned or audited.**

# Enterprise Cybersecurity Risk Register and Assessment

A ten-scenario enterprise risk assessment connecting technical weaknesses to business consequences, owners and measurable treatment plans.

## Review in five minutes

1. Read the [scoring and risk appetite](docs/methodology.md).
2. Filter the [risk register](register/risk-register.csv) by current score, owner, or treatment deadline.
3. Review the [worked assessment](assessments/worked-assessment.md), [executive summary](reports/executive-summary.md), and [indicators](monitoring/indicators.csv).
4. Compare the [risk matrix](assets/risk-matrix.md) with planned targets; targets are not achieved reductions.

## Key findings

The MFA bypass is the only current Critical scenario. Four additional scenarios are High; five are Moderate. One Moderate risk is temporarily accepted, with expiry and compensating controls. Supplier resilience and entitlement risk have low evidence confidence, requiring more evidence before claiming improvement.

## Skills demonstrated

Risk identification, likelihood/impact scoring, inherent and residual risk, treatment ownership, risk appetite, KRIs/KPIs, NIST/ISO mapping, executive reporting, and transferable experience in documentation, prioritization, escalation and business decision support.

[Scenario](docs/scenario.md) · [Sources](docs/sources.md) · [Interview notes](docs/interview-talking-points.md) · [Decision log](governance/decision-log.md)

Ratings are ordinal judgments for a simulation, not quantitative loss estimates or statistically calibrated probabilities.
