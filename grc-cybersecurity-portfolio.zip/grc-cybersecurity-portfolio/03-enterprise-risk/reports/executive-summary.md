> **SIMULATION — fictional organization, assets, personnel roles, evidence, and outcomes. No live systems were scanned or audited.**

# Executive risk summary — September 30, 2026

**Decision requested in the scenario:** prioritize closure of privileged MFA bypass before production expansion. Current portfolio: 1 Critical, 4 High, 5 Moderate, 0 Low across ten distinct scenarios. Counts describe scenarios, not ten independent monetary exposures; several share assets and controls.

R-02 remains Critical at 20. R-05 staging coverage, R-06 supplier disruption, R-08 delayed database patching and R-10 excessive document access remain High at 12. Immediate attention belongs to IAM enforcement, overdue database patching and missing authenticated visibility. Low evidence confidence on supplier and entitlement controls limits assurance.

R-01 falls from inherent 25 to current 10 after the simulated gateway replacement, but future exploitation risk remains. R-03 is current 9 and temporarily accepted through Oct 30 with daily review and restricted log deletion. Acceptance is a decision, not a risk reduction or closure.

**Resource choices:** reserve IAM engineering time for Oct 7; approve the database maintenance window; fund log capacity; assign vendor and data owners to evidence collection. Avoid interpreting summed ordinal scores as a dollar benefit or return on investment. Report treatment completion only after independent retest.
