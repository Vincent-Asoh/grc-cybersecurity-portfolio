> **SIMULATION — fictional organization, assets, personnel roles, evidence, and outcomes. No live systems were scanned or audited.**

# Risk assessment method and appetite

Prepare → identify assets and objectives → describe threat event, weakness and consequence → evaluate existing controls and evidence → score inherent and current risk → select treatment → approve and monitor. This follows the general risk-assessment structure of SP 800-30; the matrix below is local policy.

## Scales and consistent application

Likelihood is an ordinal judgment over the next 12 months: 1 Rare (exceptional conditions); 2 Unlikely (limited opportunity and effective barriers); 3 Possible (credible opportunity with gaps); 4 Likely (repeatable opportunity and material gaps); 5 Almost certain (persistent exposure with few barriers). These are descriptive anchors, not probability percentages.

Impact uses the highest applicable business dimension. 1 Negligible: <4h disruption, trivial rework, no sensitive disclosure. 2 Minor: 4–8h disruption, limited internal rework. 3 Moderate: >8–24h disruption or limited customer harm requiring management response. 4 Major: >24–72h disruption or material confidential-data loss/contract harm. 5 Severe: >72h disruption or extensive customer harm threatening business continuity. Monetary losses are not estimated without data.

Score = likelihood × impact. Low=1–5, Moderate=6–11, High=12–19, Critical=20–25. Boundaries apply to all integer scores even when some products are not possible. Avoid averaging impact dimensions or subtracting an arbitrary control percentage.

**Inherent** assumes no relevant controls. **Current residual** reflects only existing evidenced controls, with explicit uncertainty. **Target residual** is a forecast after planned treatment and successful verification. A plan alone never lowers current risk. A closed vulnerability can leave business risk: patched software still faces future defects, configuration drift or compromised credentials.

## Appetite and authority

Critical: executive escalation within one day; no new production release; weekly review and immediate containment planning. High: accountable owner treatment plan within seven days; risk committee oversight; executive approval required for time-bound acceptance. Moderate: owner treatment or documented acceptance with security concurrence and monthly review. Low: owner monitoring and quarterly review. These are fictional policy choices.

Treatment choices: mitigate, avoid, transfer/share, accept. Contracts and insurance may transfer some financial consequences but do not eliminate operational accountability. Acceptance requires reason, compensating controls, named approving role, expiry, review triggers and residual score. R-03 uses the shared RA-01/EX-01 decision through Oct 30.

## Confidence and reassessment

High confidence: directly relevant fixture test confirms condition. Medium: limited sample or indirect evidence. Low: assumption or untested process. Confidence is reported separately, not multiplied into score. Reassess after incidents, architecture or supplier changes, treatment retest, KRI breaches, or exception expiry. Preserve prior scores in the decision log when changing the register.
