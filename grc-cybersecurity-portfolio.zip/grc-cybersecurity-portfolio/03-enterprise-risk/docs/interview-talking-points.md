> **SIMULATION — fictional organization, assets, personnel roles, evidence, and outcomes. No live systems were scanned or audited.**

# Interview walkthrough

## Explain current versus target risk

Suggested explanation after reviewing the artifacts: “I scored ten business scenarios using consistent anchors and kept current residual risk separate from planned targets. MFA on five of six paths did not reduce a critical bypass risk just because most paths were covered.”

## Show the work

Walk through R-02 and explain unchanged impact. Discuss confidence on R-06 and R-10.

## Follow-up: How do you use transferable risk experience?

I would connect my actual experience with documenting issues, assessing impact, assigning owners, tracking deadlines and escalating exceptions. I would name only experience I truly have; the cyber examples here are simulations.

## Honest positioning

Describe this as a self-directed portfolio simulation. Say “I modeled” or “I analyzed the supplied synthetic cases,” not “I secured a real enterprise” or “I operated Nessus/Qualys in production.” Read and personalize the explanation before using it. Discuss a limitation and what evidence you would collect next in an authorized environment.
