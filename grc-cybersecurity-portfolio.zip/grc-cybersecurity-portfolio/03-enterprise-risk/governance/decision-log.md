> **SIMULATION — fictional organization, assets, personnel roles, evidence, and outcomes. No live systems were scanned or audited.**

# Risk committee decision log

| Date | Risk / decision | Evidence and authority | Next step |
|---|---|---|---|
| Sep 4 | R-01 current risk set to 10 after gateway remediation | V-001 retest; Operations Director concurs | Monthly exposure review; target 5 remains prospective |
| Sep 20 | R-03 temporary acceptance at 9 through Oct 30 | RA-01 / EX-01; simulated executive approval | Weekly controls review; retain original VM SLA |
| Sep 30 | R-02 remains 20; release acceptance rejected | EV-02 / F-01; risk committee and executive role | IAM due Oct 7; reconsider after retest |
| Sep 30 | R-06 and R-10 retain low evidence confidence | No exercise/entitlement results available | Request supplier and data-owner evidence |

For each future change preserve previous score, new score, evidence ID, decision-maker, date and rationale. The full initial score set remains in the register; this log illustrates material decisions rather than inventing a prior monthly trend.
