> **SIMULATION — fictional organization, assets, personnel roles, evidence, and outcomes. No live systems were scanned or audited.**

# GRC & Vulnerability Management Portfolio

Four connected, standalone case studies for **GRC Analyst** and **Vulnerability Management Analyst** roles. The portfolio demonstrates how to turn system context and security evidence into prioritized findings, accountable treatment plans and business decisions.

All organization and operational data are fictional. Real framework and CVE references are used only as learning material. No real scan, audit, authorization, certification or employment achievement is claimed.

| Project | Business question | Start here |
|---|---|---|
| 01 · NIST RMF / SSP / ATO | Is the system ready for a risk-based release decision? | [Authorization package](01-nist-rmf-ato/README.md) |
| 02 · Vulnerability management | What should be fixed first, and how do we verify it? | [Program and case data](02-vulnerability-management/README.md) |
| 03 · Enterprise risk | Which business risks need treatment or acceptance? | [Risk assessment](03-enterprise-risk/README.md) |
| 04 · Control assessment / audit | What does the evidence support against applicable criteria? | [Audit workpapers](04-control-assessment/README.md) |

## Demonstrated capabilities

GRC, NIST RMF, NIST SP 800-53, NIST CSF 2.0, ISO/IEC 27001 mapping, vulnerability management, CVE/CVSS, Nessus and Qualys VMDR workflow concepts, asset discovery, authenticated scanning, false-positive validation, patch/remediation management, risk acceptance, security controls, audit/compliance and executive communication.

The transferable risk skills are explicit: defining scope, assessing business impact, reconciling evidence, documenting decisions, assigning owners, tracking deadlines and escalating unresolved issues. This portfolio does not assume or invent a professional's employment history.

## Suggested review path

Start with the four project READMEs, then trace the MFA issue across the [portfolio traceability map](PORTFOLIO-TRACEABILITY.md). Next inspect the VM false-positive example and reproduce the metrics. Finish with the audit executive summary and discuss where the evidence is insufficient.

The simulated snapshot is September 30, 2026. Operational outcomes are deliberately mixed: some remediation succeeds, some deadlines are missed, and authorization is withheld. Planned treatment is never presented as completed work.

## Contents and reuse

Each project contains a professional README, methodology, populated CSV/Markdown artifacts, source references, a diagram, optional screenshot guidance and interview notes. CSVs use UTF-8, ISO dates and an explicit simulation flag. All required sample content is complete; screenshot slots are optional future lab additions.

Use one portfolio repository or publish the four folders as separate repositories. Each project is self-contained. See [GitHub upload instructions](GITHUB-UPLOAD.md), [data conventions](DATA-CONVENTIONS.md), and [quality report](QUALITY-REPORT.md). No real account or secret is required to review the files.

## Interview positioning

“I built a fictional GRC and vulnerability-management portfolio that links control evidence, validated vulnerabilities, business risk and audit actions. I can explain the decisions, calculate the metrics and identify the limits of the evidence.” Personalize this only after reviewing the work and distinguish simulation from your actual experience.
