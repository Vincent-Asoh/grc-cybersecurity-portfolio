> **SIMULATION — fictional organization, assets, personnel roles, evidence, and outcomes. No live systems were scanned or audited.**

# Data conventions and reproducibility

All CSV rows have `simulation=TRUE`. IDs are stable join keys. Dates use YYYY-MM-DD; due dates count calendar days from first detection and remain effective through end of day. The fixed reporting cutoff is 2026-09-30. Blank means unavailable/not populated for the field; `n.a.` means not applicable; `unknown` indicates missing evidence. No formulas or macros are embedded in CSVs.

Raw-style observations are normalized into findings; only normalized valid cases feed VM metrics. Accepted cases remain unresolved and retain original SLA dates. False positives are retained for auditability but excluded from valid-case metrics. Current residual and target risk are separate columns; multiplying likelihood and impact reproduces each score.

Every project includes `docs/scenario.md` and `docs/sources.md`, so copying a folder does not remove its context. Source summaries are paraphrases, not reproduced standards. A local framework mapping is a reasoned relationship, not a compliance equivalence.

The VM metrics script uses only Python's standard library and reads local CSVs. It performs no network access or scanning. Its default command prints a Markdown report without modifying files; `--write` refreshes the scorecard. Use Python 3.10 or newer. For other CSV edits, review linked narratives and decisions as well as numeric fields.
