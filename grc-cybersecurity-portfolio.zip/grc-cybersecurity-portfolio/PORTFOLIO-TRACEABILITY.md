> **SIMULATION — fictional organization, assets, personnel roles, evidence, and outcomes. No live systems were scanned or audited.**

# Cross-project traceability

| Shared business issue | RMF | VM | Risk | Audit |
|---|---|---|---|---|
| Privileged MFA bypass | F-01 / P-01 / EV-02 | V-004 | R-02 | AF-01 / CA-01 |
| Log retention gap | F-02 / P-02 / RA-01 | V-006 / EX-01 | R-03 | AF-03 / CA-03 |
| A03 expired scan credential | F-03 / P-03 closed Sep 28 | V-012 closed Sep 28 | R-08 evidence context | E-03 / W-03 includes timely V-012 closure |
| Gateway critical exposure | EV-05 supporting context | V-001 / CHG-001 closed Sep 4 | R-01 | E-03 and E-07 |
| Database patch delay | SI-2 broader program context | V-005 overdue | R-08 | AF-02 / CA-02 |
| Staging visibility | Outside scoped A03 RMF test | V-009; local checks fail | R-05 | E-05 inventory passes only; no claim of scan coverage |
| Recovery performance | EV-06 | A06 context | R-04 | E-06 / W-06 |
| Supplier assurance | Inheritance limitation | No finding represented | R-06 | AF-04 / CA-04 |

Scope differences are intentional. RMF evaluates selected objectives within an application authorization exercise; VM covers eight enterprise assets; the register evaluates business scenarios; audit tests eight criteria. Counts across these projects are not additive. RA-01 and EX-01 represent one shared acceptance decision, not two approvals. V-004 retains the shared Sep 14 first-detection date; its Oct 7 POA&M target does not erase the Sep 28 VM SLA breach.
