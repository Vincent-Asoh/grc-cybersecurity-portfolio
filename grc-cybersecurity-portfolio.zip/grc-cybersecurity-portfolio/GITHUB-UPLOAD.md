> **SIMULATION — fictional organization, assets, personnel roles, evidence, and outcomes. No live systems were scanned or audited.**

# Publish the portfolio on GitHub

## One portfolio repository

1. Extract `grc-cybersecurity-portfolio.zip` on your computer.
2. Create a new GitHub repository named `grc-cybersecurity-portfolio` (or a name you prefer).
3. Open the extracted `grc-cybersecurity-portfolio` folder. Upload its contents, including root README and the four project folders, into the repository root. Do not upload only the ZIP; GitHub should display the Markdown and CSV files directly.
4. Commit the files. Confirm the root README links and Mermaid diagrams render.
5. Add a description such as “Fictional GRC and vulnerability-management case studies covering RMF, CVE/CVSS, risk assessment and control audit.” Suggested topics: `grc`, `cybersecurity`, `nist-rmf`, `vulnerability-management`, `risk-assessment`, `security-audit`.

## Four separate repositories

Extract each project ZIP and upload the contents of its top-level project folder to a matching new repository. Each has its own README, sources and context. Optionally publish the combined portfolio as an index and replace its local project links with the actual repository URLs after creation. No GitHub username or URL has been invented.

## Before sharing

Read the interview notes and personalize descriptions of your contribution. Keep simulation labels. Replace optional screenshot slots only with your own authorized lab captures. Do not add real employer evidence, credentials, customer data or unearned claims. Add a license only if you decide the terms under which you want others to reuse your original work; no license is selected on your behalf.

The package contains files only. It does not create or publish GitHub repositories automatically.
